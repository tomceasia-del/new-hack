# 🔐 Agent 1: Authentication & License System

> **Dependencies:** None (เริ่มก่อนได้เลย)  
> **Output:** Auth service, License validation

---

## 🎯 Scope

- User registration/login
- License key validation
- Device management
- Session management

---

## 📱 UX Requirements (One-Handed)

### Login Screen

```
┌─────────────────────────┐
│                         │
│      🔐 Project CS          │
│                         │
│   ┌─────────────────┐   │
│   │ License Key     │   │  ← Auto-format XXXX-XXXX
│   └─────────────────┘   │
│                         │
│   ┌─────────────────┐   │
│   │ Paste from      │   │  ← ปุ่มใหญ่ กดง่าย
│   │ Clipboard 📋    │   │
│   └─────────────────┘   │
│                         │
│                         │
│                         │
├─────────────────────────┤
│  ┌───────────────────┐  │
│  │    เปิดใช้งาน     │  │  ← Primary button ล่างสุด
│  └───────────────────┘  │
└─────────────────────────┘
```

### Features

1. **Paste License** — กดปุ่มเดียว paste จาก clipboard
2. **Auto-format** — พิมพ์ `AAAA` กลายเป็น `AAAA-` อัตโนมัติ
3. **Biometric** — Face ID / Fingerprint สำหรับ login ครั้งถัดไป
4. **Remember** — ไม่ต้อง login ซ้ำ

---

## 🔥 Firebase Configuration

```typescript
// config/firebase.ts
export const FIREBASE_CONFIG = {
  apiKey: "AIzaSyAU2sHCYyC9jTJMw41HzCX6USaNvcx6MEM",
  authDomain: "oneclick-admin-2026-841a8.firebaseapp.com",
  databaseURL: "https://oneclick-admin-2026-841a8-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "oneclick-admin-2026-841a8",
  storageBucket: "oneclick-admin-2026-841a8.firebasestorage.app",
  messagingSenderId: "795789916740",
  appId: "1:795789916740:web:edd75421fe8d27e2449a11",
  measurementId: "G-GSFBJ5GH2R"
};

// ⚠️ สำหรับ Production: สร้าง Firebase Project ใหม่ของทีมเอง
```

---

## 🔑 License Service

### Data Model

```typescript
// types/license.ts
interface License {
  licenseKey: string;           // XXXX-XXXX-XXXX-XXXX
  expiresAt?: string;           // ISO date or null = unlimited
  disabled: boolean;
  maxDevices: number;           // Default: 4
  devices: Record<string, Device>;
}

interface Device {
  deviceId: string;
  deviceName: string;           // "iPhone 15 Pro"
  platform: 'ios' | 'android' | 'web';
  registeredAt: string;
  lastSeen: string;
}
```

### License Validation Flow

```typescript
// services/licenseService.ts
import { getDatabase, ref, get, set, remove } from 'firebase/database';

const FIREBASE_DB_URL = "https://oneclick-admin-2026-841a8-default-rtdb.asia-southeast1.firebasedatabase.app";
const MAX_DEVICES = 4;

export class LicenseService {
  private deviceId: string;
  
  constructor() {
    this.deviceId = this.getOrCreateDeviceId();
  }
  
  // สร้าง Device ID unique ต่อเครื่อง
  private getOrCreateDeviceId(): string {
    let deviceId = localStorage.getItem('deviceId');
    if (!deviceId) {
      deviceId = `mobile_${Date.now()}_${Math.random().toString(36).slice(2, 11)}`;
      localStorage.setItem('deviceId', deviceId);
    }
    return deviceId;
  }
  
  // Validate License Key
  async validateLicense(licenseKey: string): Promise<LicenseResult> {
    const cleanKey = licenseKey.trim().toUpperCase();
    
    try {
      // 1. Fetch license from Firebase
      const response = await fetch(
        `${FIREBASE_DB_URL}/licenses/${cleanKey}.json`
      );
      
      if (!response.ok) {
        return { success: false, error: 'ไม่สามารถเชื่อมต่อ Server ได้' };
      }
      
      const license: License = await response.json();
      
      // 2. License not found
      if (!license) {
        return { success: false, error: 'License Key ไม่ถูกต้อง' };
      }
      
      // 3. Check expiry
      if (license.expiresAt && new Date(license.expiresAt) < new Date()) {
        return { success: false, error: 'License Key หมดอายุแล้ว' };
      }
      
      // 4. Check disabled
      if (license.disabled) {
        return { success: false, error: 'License Key ถูกระงับการใช้งาน' };
      }
      
      // 5. Check devices
      const devices = license.devices || {};
      const deviceIds = Object.keys(devices);
      
      // Already registered
      if (devices[this.deviceId]) {
        await this.updateLastSeen(cleanKey);
        return { 
          success: true, 
          message: 'ยินดีต้อนรับกลับ!',
          devicesUsed: deviceIds.length,
          maxDevices: MAX_DEVICES
        };
      }
      
      // Too many devices
      if (deviceIds.length >= MAX_DEVICES) {
        return { 
          success: false, 
          error: `License ใช้งานครบ ${MAX_DEVICES} เครื่องแล้ว`,
          devicesUsed: deviceIds.length,
          maxDevices: MAX_DEVICES
        };
      }
      
      // 6. Register new device
      await this.registerDevice(cleanKey);
      
      return { 
        success: true, 
        message: `ลงทะเบียนสำเร็จ! (${deviceIds.length + 1}/${MAX_DEVICES})`,
        devicesUsed: deviceIds.length + 1,
        maxDevices: MAX_DEVICES
      };
      
    } catch (error) {
      return { success: false, error: 'เกิดข้อผิดพลาด: ' + error.message };
    }
  }
  
  // Register device
  private async registerDevice(licenseKey: string): Promise<void> {
    const deviceData: Device = {
      deviceId: this.deviceId,
      deviceName: this.getDeviceName(),
      platform: this.getPlatform(),
      registeredAt: new Date().toISOString(),
      lastSeen: new Date().toISOString()
    };
    
    await fetch(
      `${FIREBASE_DB_URL}/licenses/${licenseKey}/devices/${this.deviceId}.json`,
      {
        method: 'PUT',
        body: JSON.stringify(deviceData)
      }
    );
  }
  
  // Update last seen
  private async updateLastSeen(licenseKey: string): Promise<void> {
    await fetch(
      `${FIREBASE_DB_URL}/licenses/${licenseKey}/devices/${this.deviceId}/lastSeen.json`,
      {
        method: 'PUT',
        body: JSON.stringify(new Date().toISOString())
      }
    );
  }
  
  // Get device name
  private getDeviceName(): string {
    // React Native: use device-info library
    // Web: use navigator.userAgent parsing
    return 'Mobile Device';
  }
  
  // Get platform
  private getPlatform(): 'ios' | 'android' | 'web' {
    // Detect platform
    return 'web';
  }
  
  // Remove device (for device management screen)
  async removeDevice(licenseKey: string, deviceId: string): Promise<boolean> {
    try {
      await fetch(
        `${FIREBASE_DB_URL}/licenses/${licenseKey}/devices/${deviceId}.json`,
        { method: 'DELETE' }
      );
      return true;
    } catch {
      return false;
    }
  }
  
  // Get all devices
  async getDevices(licenseKey: string): Promise<Device[]> {
    const response = await fetch(
      `${FIREBASE_DB_URL}/licenses/${licenseKey}/devices.json`
    );
    const devices = await response.json();
    return Object.values(devices || {});
  }
}

// Result type
interface LicenseResult {
  success: boolean;
  message?: string;
  error?: string;
  devicesUsed?: number;
  maxDevices?: number;
}
```

---

## 🔒 HMAC Signature (Optional Security Layer)

```typescript
// utils/hmac.ts
const HMAC_SECRET = "Lic_S1gn_K3y_2026";

// Sign license data (FNV-1a hash)
export function signLicense(licenseKey: string, deviceId: string): string {
  const data = `${licenseKey}|${deviceId}|${HMAC_SECRET}`;
  let hash = 0x811c9dc5;
  
  for (let i = 0; i < data.length; i++) {
    hash ^= data.charCodeAt(i);
    hash = Math.imul(hash, 0x01000193);
  }
  
  return (hash >>> 0).toString(36);
}

// Verify signature
export function verifyLicense(
  licenseKey: string, 
  deviceId: string, 
  signature: string
): boolean {
  return signLicense(licenseKey, deviceId) === signature;
}
```

---

## 💾 Local Storage

```typescript
// services/storage.ts
import AsyncStorage from '@react-native-async-storage/async-storage';

const KEYS = {
  LICENSE_KEY: 'license_key',
  LICENSE_DATA: 'license_data',
  DEVICE_ID: 'device_id',
  SIGNATURE: 'license_signature',
};

export const StorageService = {
  // Save license locally
  async saveLicense(licenseKey: string, signature: string): Promise<void> {
    await AsyncStorage.multiSet([
      [KEYS.LICENSE_KEY, licenseKey],
      [KEYS.SIGNATURE, signature],
    ]);
  },
  
  // Load license
  async loadLicense(): Promise<{ key: string; signature: string } | null> {
    const [[, key], [, signature]] = await AsyncStorage.multiGet([
      KEYS.LICENSE_KEY,
      KEYS.SIGNATURE,
    ]);
    
    if (!key || !signature) return null;
    return { key, signature };
  },
  
  // Clear license (logout)
  async clearLicense(): Promise<void> {
    await AsyncStorage.multiRemove([KEYS.LICENSE_KEY, KEYS.SIGNATURE]);
  },
};
```

---

## 🎨 UI Components

### License Input with Auto-Format

```tsx
// components/LicenseInput.tsx
import React, { useState } from 'react';
import { TextInput, TouchableOpacity, View, Text, Clipboard } from 'react-native';

export function LicenseInput({ onSubmit }) {
  const [value, setValue] = useState('');
  
  // Auto-format: XXXX-XXXX-XXXX-XXXX
  const handleChange = (text: string) => {
    const clean = text.replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    let formatted = '';
    
    for (let i = 0; i < clean.length && i < 16; i++) {
      if (i > 0 && i % 4 === 0) formatted += '-';
      formatted += clean[i];
    }
    
    setValue(formatted);
  };
  
  // Paste from clipboard
  const handlePaste = async () => {
    const text = await Clipboard.getString();
    handleChange(text);
  };
  
  return (
    <View>
      <TextInput
        value={value}
        onChangeText={handleChange}
        placeholder="XXXX-XXXX-XXXX-XXXX"
        autoCapitalize="characters"
        maxLength={19}
        style={styles.input}
      />
      
      <TouchableOpacity onPress={handlePaste} style={styles.pasteButton}>
        <Text>📋 Paste from Clipboard</Text>
      </TouchableOpacity>
      
      <TouchableOpacity 
        onPress={() => onSubmit(value)}
        style={styles.submitButton}
        disabled={value.length < 19}
      >
        <Text style={styles.submitText}>เปิดใช้งาน</Text>
      </TouchableOpacity>
    </View>
  );
}
```

### Device Management Bottom Sheet

```tsx
// components/DeviceManagement.tsx
export function DeviceManagement({ devices, currentDeviceId, onRemove }) {
  return (
    <BottomSheet snapPoints={['50%', '90%']}>
      <Text style={styles.title}>อุปกรณ์ที่ลงทะเบียน</Text>
      <Text style={styles.subtitle}>{devices.length}/4 เครื่อง</Text>
      
      {devices.map(device => (
        <SwipeableRow
          key={device.deviceId}
          onSwipeLeft={() => onRemove(device.deviceId)}
        >
          <View style={styles.deviceRow}>
            <View>
              <Text>{device.deviceName}</Text>
              <Text style={styles.caption}>
                {device.deviceId === currentDeviceId ? '📱 เครื่องนี้' : ''}
              </Text>
            </View>
            <Text style={styles.date}>
              {formatDate(device.lastSeen)}
            </Text>
          </View>
        </SwipeableRow>
      ))}
    </BottomSheet>
  );
}
```

---

## ✅ Checklist

- [ ] Firebase connection
- [ ] License validation API
- [ ] Device registration
- [ ] Local storage persistence
- [ ] Auto-format license input
- [ ] Paste from clipboard
- [ ] Device management UI
- [ ] Biometric authentication
- [ ] Error handling & messages
- [ ] Offline detection

---

## 🔗 Integration Points

| ส่งให้ | Data |
|--------|------|
| **All Agents** | `isLicenseValid: boolean` |
| **Backend Agent** | License validation endpoint |
| **UI Agent** | Login/Device management screens |
