# 📱 Project CS Mobile/Web App — Overview & UX Guidelines

> **สำหรับ:** ทุก Agent  
> **อ่านก่อนเริ่มงาน:** บังคับ

---

## 🎯 Vision

สร้าง App สร้างคอนเทนต์วิดีโอสั้นที่:
- **ง่าย** — ใช้งานได้ทันทีไม่ต้องเรียนรู้
- **ทันสมัย** — UI/UX ระดับ TikTok, Instagram
- **มือเดียว** — ใช้นิ้วโป้งมือเดียวทำทุกอย่างได้

---

## 📐 One-Handed UX Rules (บังคับทุก Agent)

### 1. Thumb Zone Design

```
┌─────────────────────────┐
│                         │  ❌ Hard to reach
│                         │     (ห้ามวางปุ่มสำคัญ)
│                         │
├─────────────────────────┤
│                         │  ⚠️ Stretch zone
│                         │     (ปุ่มรองได้)
│                         │
├─────────────────────────┤
│  ✅ EASY ZONE           │  ✅ Natural thumb area
│  ปุ่มหลักอยู่ตรงนี้      │     (ปุ่มหลักทั้งหมด)
│                         │
└─────────────────────────┘
      📱 (มือขวา)
```

### 2. Component Placement Rules

| Element | ตำแหน่ง | เหตุผล |
|---------|---------|--------|
| **Primary Action** | ล่างขวา | นิ้วโป้งถึงง่าย |
| **Navigation** | ล่างสุด | Tab bar มาตรฐาน |
| **Cancel/Back** | ล่างซ้าย | เอื้อมถึงได้ |
| **Content** | กลาง-บน | ดูได้ไม่บังมือ |
| **Settings** | ซ่อนใน menu | ไม่ใช้บ่อย |

### 3. Touch Target Sizes

```css
/* Minimum touch targets */
.button-primary {
  min-height: 56px;      /* ใหญ่พอกดง่าย */
  min-width: 56px;
  border-radius: 28px;   /* มน กดได้ทุกมุม */
}

.button-secondary {
  min-height: 48px;
  padding: 12px 24px;
}

.list-item {
  min-height: 64px;      /* กดได้ทั้งแถว */
  padding: 16px;
}
```

### 4. Gesture-First Interactions

| Action | Gesture | ไม่ใช่ |
|--------|---------|-------|
| ลบ item | ← Swipe left | ❌ กดปุ่มถังขยะเล็กๆ |
| Refresh | ↓ Pull down | ❌ กดปุ่ม refresh |
| Next step | → Swipe right | ❌ กดปุ่ม Next |
| Close modal | ↓ Swipe down | ❌ กดปุ่ม X |
| Select multiple | Long press | ❌ Checkbox เล็กๆ |

### 5. Bottom Sheet > Modal

```
✅ ใช้ Bottom Sheet          ❌ อย่าใช้ Center Modal
┌─────────────────────┐     ┌─────────────────────┐
│                     │     │   ┌───────────┐     │
│                     │     │   │   Modal   │     │
│                     │     │   │  ต้องเอื้อม │     │
│ ┌─────────────────┐ │     │   │   ไปกด    │     │
│ │  Bottom Sheet   │ │     │   └───────────┘     │
│ │  นิ้วโป้งถึง     │ │     │                     │
│ └─────────────────┘ │     └─────────────────────┘
└─────────────────────┘
```

---

## 🎨 Design System

### Colors

```css
:root {
  /* Primary */
  --primary: #6C5CE7;        /* สีม่วงทันสมัย */
  --primary-light: #A29BFE;
  --primary-dark: #5541D7;
  
  /* Status */
  --success: #00D9A5;
  --warning: #FECA57;
  --error: #FF6B6B;
  
  /* Neutral */
  --bg-primary: #0D0D0D;     /* Dark mode default */
  --bg-secondary: #1A1A1A;
  --bg-card: #242424;
  --text-primary: #FFFFFF;
  --text-secondary: #8E8E93;
  
  /* Gradients */
  --gradient-primary: linear-gradient(135deg, #6C5CE7, #A29BFE);
  --gradient-tiktok: linear-gradient(135deg, #FE2C55, #25F4EE);
}
```

### Typography

```css
/* Font: SF Pro (iOS) / Roboto (Android) */
--font-display: 32px, weight 700;    /* หัวข้อใหญ่ */
--font-title: 24px, weight 600;      /* หัวข้อ */
--font-body: 16px, weight 400;       /* เนื้อหา */
--font-caption: 14px, weight 400;    /* คำอธิบาย */
--font-small: 12px, weight 400;      /* เล็กสุด */
```

### Spacing

```css
--space-xs: 4px;
--space-sm: 8px;
--space-md: 16px;
--space-lg: 24px;
--space-xl: 32px;
--space-xxl: 48px;
```

---

## 🏗️ App Structure

### Bottom Navigation (5 tabs max)

```
┌─────┬─────┬─────┬─────┬─────┐
│ 🏠  │ 📦  │ ➕  │ 📊  │ 👤  │
│Home │Queue│ New │Stats│ Me  │
└─────┴─────┴─────┴─────┴─────┘
```

| Tab | หน้าที่ |
|-----|--------|
| **Home** | ภาพรวม, quick actions |
| **Queue** | รายการรอโพสต์ |
| **+ New** | สร้างคอนเทนต์ใหม่ (FAB style) |
| **Stats** | สถิติ, dashboard |
| **Me** | Profile, settings |

### Core User Flows

```
Flow 1: สร้างคอนเทนต์ (3 taps)
┌──────┐    ┌──────┐    ┌──────┐    ┌──────┐
│  +   │ → │ถ่าย/  │ → │  AI  │ → │ Done │
│ New  │    │เลือก  │    │สร้าง │    │  ✓   │
└──────┘    └──────┘    └──────┘    └──────┘

Flow 2: โพสต์ (2 taps)
┌──────┐    ┌──────┐    ┌──────┐
│Queue │ → │Swipe │ → │Posted│
│ Item │    │ Post │    │  ✓   │
└──────┘    └──────┘    └──────┘
```

---

## 📁 Agent Files

| ไฟล์ | Agent | ทำอะไร |
|------|-------|--------|
| `01_AUTH_LICENSE.md` | Auth Agent | Login, License, Firebase |
| `02_AI_GENERATION.md` | AI Agent | Gemini, OpenAI, Prompts |
| `03_PLATFORM_TIKTOK.md` | TikTok Agent | TikTok API integration |
| `04_PLATFORM_FACEBOOK.md` | Facebook Agent | Facebook/IG Reels |
| `05_PLATFORM_YOUTUBE.md` | YouTube Agent | YouTube Shorts |
| `06_UI_COMPONENTS.md` | UI Agent | React Native components |
| `07_DATABASE.md` | DB Agent | Schema, migrations |
| `08_BACKEND_API.md` | Backend Agent | Express/Fastify server |

---

## 🔗 Shared Interfaces

ทุก Agent ต้องใช้ interfaces เหล่านี้ร่วมกัน:

```typescript
// User
interface User {
  id: string;
  email: string;
  licenseKey?: string;
  licenseExpiry?: Date;
  createdAt: Date;
}

// Content Item
interface ContentItem {
  id: string;
  userId: string;
  productName: string;
  productImage?: string;
  
  // Generated
  script?: string;
  imagePrompt?: string;
  videoPrompt?: string;
  videoUrl?: string;
  
  // Status
  status: 'draft' | 'generating' | 'ready' | 'posting' | 'posted' | 'failed';
  platforms: Platform[];
  
  // Timestamps
  createdAt: Date;
  postedAt?: Date;
}

// Platform
type Platform = 'tiktok' | 'facebook' | 'youtube';

// Post Result
interface PostResult {
  platform: Platform;
  success: boolean;
  postId?: string;
  postUrl?: string;
  error?: string;
}
```

---

## ⚡ Performance Requirements

| Metric | Target |
|--------|--------|
| App launch | < 2 seconds |
| Screen transition | < 300ms |
| AI generation start | < 1 second |
| Touch response | < 100ms |
| Offline support | Queue งานได้ |

---

## 🚀 Priority Order

1. **P0 (Week 1-2):** Auth + AI Generation + Basic UI
2. **P1 (Week 3-4):** TikTok Integration + Queue
3. **P2 (Week 5-6):** Facebook + YouTube
4. **P3 (Week 7+):** Analytics + Polish

---

**อ่านไฟล์นี้จบแล้ว → ไปอ่านไฟล์ของ Agent ตัวเองได้เลย!**
